export class ResizeObserver {
  constructor() {}

  disconnect() {}
  observe() {}
  unobserve() {}
}