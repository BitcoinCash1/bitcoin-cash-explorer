import { InjectionToken } from '@angular/core';

export const ZONE_SERVICE = new InjectionToken('ZONE_TASK');